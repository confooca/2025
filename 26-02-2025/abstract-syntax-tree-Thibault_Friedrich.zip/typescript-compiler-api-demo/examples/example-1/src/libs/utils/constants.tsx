export const Constants = {
  FOO: 'foo',
  BAR: 'bar',
}
