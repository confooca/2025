export const useBar = () => {
  return 'bar'
}
