export function useFoo() {
  return 'foo'
}
