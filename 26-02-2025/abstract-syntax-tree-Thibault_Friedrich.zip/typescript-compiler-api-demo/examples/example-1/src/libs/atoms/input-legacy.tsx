import React from 'react'

export default class InputLegacy extends React.Component {
  render() {
    return <input />
  }
}
