/**
 * Work in progress
 *
 * > Please don't use this component yet, it's still in development.
 */
export function Icon() {
  return <div>work in progress</div>
}
