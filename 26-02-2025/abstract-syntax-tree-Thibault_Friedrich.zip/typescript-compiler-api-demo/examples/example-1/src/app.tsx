import { Button } from './libs/atoms/button'

export function App() {
  return (
    <div>
      <Button variant='primary'>fds</Button>
    </div>
  )
}
