export function Foo() {
  return <div>Foo</div>
}
