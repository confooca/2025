export function Foo({
  one,
  two,
  three,
}: {
  one: string
  two: number
  three: boolean
}) {
  return <div>Foo</div>
}
