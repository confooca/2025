export const Foo = () => {
  return <div>Foo</div>
}
