// @deprecated
export const Foo = () => {
  return <div>foo</div>
}
