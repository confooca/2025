const Foo = function () {
  return <div>Foo</div>
}

export { Foo }
