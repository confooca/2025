export const Foo = function () {
  return <div>Foo</div>
}
