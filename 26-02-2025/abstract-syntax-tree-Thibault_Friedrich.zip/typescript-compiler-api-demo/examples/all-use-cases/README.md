# All use cases

This is a collection of all use cases that are supported by the parser. They should be play individually to see how the parser behaves in different scenarios.
