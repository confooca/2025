const Foo = ({ one = () => {} }: { one: VoidFunction }) => {
  return <div>Foo</div>
}

export default Foo
