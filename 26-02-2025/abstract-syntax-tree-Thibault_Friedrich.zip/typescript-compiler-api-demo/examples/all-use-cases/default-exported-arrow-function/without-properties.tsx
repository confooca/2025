const Foo = () => {
  return <div>Foo</div>
}

export default Foo
