export default function Foo() {
  return <div>Foo</div>
}
