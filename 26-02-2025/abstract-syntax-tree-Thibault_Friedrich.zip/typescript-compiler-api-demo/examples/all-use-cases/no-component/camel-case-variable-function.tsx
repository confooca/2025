export const camelCaseFunction = function () {
  return <div />
}
