export function camelCaseFunction() {
  return <div />
}
