export const camelCaseArrowFunction = () => <div />
