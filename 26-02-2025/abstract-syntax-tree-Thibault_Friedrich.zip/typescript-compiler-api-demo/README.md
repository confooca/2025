# typescript Compiler API

## Getting started

```bash
pnpm install 
pnpm dev
```

## Links

- https://github.com/Microsoft/TypeScript/wiki/Using-the-Compiler-API#using-the-type-checker