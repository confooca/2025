export function isPascalCase(s: string) {
  return /^[A-Z]/.test(s)
}
